---
currentMenu: demo
---

## Demo
[https://demo.filegator.io](https://demo.filegator.io)

This is read-only demo with guest account enabled.

- you can log in as `john/john` to see John's private files
- or `jane/jane` as readonly + download user.
